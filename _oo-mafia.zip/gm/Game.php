<?php
class Game {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function addPlayer($gameRoom, $playerUsername) {
        $sql = "SELECT * FROM users WHERE username=?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param('s', $playerUsername);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $sql = "SELECT * FROM games WHERE game_room=?";
            $stmt = $this->db->prepare($sql);
            $stmt->bind_param('s', $gameRoom);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $players = $row['players'];
                if (strpos($players, $playerUsername) === false) {
                    $players .= $playerUsername . ",";
                    $sql = "UPDATE games SET players=? WHERE game_room=?";
                    $stmt = $this->db->prepare($sql);
                    $stmt->bind_param('ss', $players, $gameRoom);
                    if ($stmt->execute()) {
                        return "Player added successfully!";
                    } else {
                        return "Error: " . $this->db->getLastError();
                    }
                } else {
                    return "Player is already in the game room.";
                }
            } else {
                return "Game room not found.";
            }
        } else {
            return "Player not found.";
        }
    }

    public function startGame($gameRoom) {
        $sql = "SELECT * FROM games WHERE game_room=?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param('s', $gameRoom);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $players = rtrim($row['players'], ',');
            $playersArray = explode(',', $players);
            $playerCount = count($playersArray);

            if ($playerCount >= 4) {
                // Delete old game results
                $sql = "DELETE FROM game_results WHERE game_room=?";
                $stmt = $this->db->prepare($sql);
                $stmt->bind_param('s', $gameRoom);
                if (!$stmt->execute()) {
                    return "Error deleting old game results: " . $this->db->getLastError();
                }

                shuffle($playersArray);

                if ($playerCount >= 6 && $playerCount <= 10) {
                    $roles = ['Şerif', 'Don Mafia', 'Mafia', 'Komikadze'];
                } elseif ($playerCount > 10) {
                    $roles = ['Şerif', 'Don Mafia', 'Mafia', 'Consigliere', 'Komikadze', 'Doktor'];
                } else {
                    return "Not enough players to start the game.";
                }

                $remainingRoles = array_fill(0, $playerCount - count($roles), 'Sakin');
                $roles = array_merge($roles, $remainingRoles);

                $mafiaPlayers = [];
                $donMafiaPlayers = [];
                $consigliere = [];

                foreach ($playersArray as $index => $player) {
                    $role = $roles[$index];
                    if ($role == 'Mafia') {
                        $mafiaPlayers[] = $player;
                    } elseif ($role == 'Don Mafia') {
                        $donMafiaPlayers[] = $player;
                    } elseif ($role == 'Consigliere') {
                        $consigliere[] = $player;
                    }
                    $sql = "INSERT INTO game_results (username, role, game_room) VALUES (?, ?, ?)";
                    $stmt = $this->db->prepare($sql);
                    $stmt->bind_param('sss', $player, $role, $gameRoom);
                    $stmt->execute();
                }

                $mafiaPlayersStr = implode(',', $mafiaPlayers);
                $donMafiaPlayersStr = implode(',', $donMafiaPlayers);
                $consigliereStr = implode(',', $consigliere);

                $sql = "UPDATE games SET status='started', mafia_players=?, don_mafia_players=?, consigliere=? WHERE game_room=?";
                $stmt = $this->db->prepare($sql);
                $stmt->bind_param('ssss', $mafiaPlayersStr, $donMafiaPlayersStr, $consigliereStr, $gameRoom);
                $stmt->execute();

                return "Game started successfully!";
            } else {
                return "Not enough players to start the game.";
            }
        } else {
            return "Game room not found.";
        }
    }

    public function getLastGameResult($username) {
        $sql = "SELECT game_room, role FROM game_results WHERE username=? ORDER BY assigned_at DESC LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $lastGameResult = null;
        if ($result->num_rows > 0) {
            $lastGameResult = $result->fetch_assoc();
        }
        return $lastGameResult;
    }

    public function getSpecialInfo($gameRoom, $role) {
        $sql = "SELECT mafia_players, don_mafia_players, consigliere FROM games WHERE game_room=?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param('s', $gameRoom);
        $stmt->execute();
        $result = $stmt->get_result();
        $specialInfo = '';
        if ($result->num_rows > 0) {
            $gameInfo = $result->fetch_assoc();
            if ($role == 'Mafia') {
                $specialInfo = 'Don Mafia: ' . htmlspecialchars($gameInfo['don_mafia_players']) . ' || Mafia: ' . htmlspecialchars($gameInfo['mafia_players']) . ' || Consigliere: ' . htmlspecialchars($gameInfo['consigliere']);
            } elseif ($role == 'Don Mafia') {
                $specialInfo = 'Mafia Players: ' . htmlspecialchars($gameInfo['mafia_players']) . ' || Consigliere: ' . htmlspecialchars($gameInfo['consigliere']);
            }
        }
        return $specialInfo;
    }
}
?>
