<?php
class GameRoom {
    private $db;
    private $creator;

    public function __construct($db, $creator) {
        $this->db = $db;
        $this->creator = $creator;
    }

    public function createRoom($gameRoom) {
        $sql = "SELECT * FROM games WHERE game_room=?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param('s', $gameRoom);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 0) {
            $sql = "INSERT INTO games (game_room, players, creator) VALUES (?, '', ?)";
            $stmt = $this->db->prepare($sql);
            $stmt->bind_param('ss', $gameRoom, $this->creator);
            if ($stmt->execute()) {
                return "New game room created successfully!";
            } else {
                return "Error: " . $this->db->getLastError();
            }
        } else {
            return "Game room already exists. Please choose a different name.";
        }
    }

    public function getUserRooms($page, $limit) {
        $offset = ($page - 1) * $limit;
        $sql = "SELECT * FROM games WHERE creator=? LIMIT ? OFFSET ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param('sii', $this->creator, $limit, $offset);
        $stmt->execute();
        $result = $stmt->get_result();
        $userRooms = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $userRooms[] = $row;
            }
        }
        return $userRooms;
    }

    public function deleteRoom($gameRoom) {
        $sql = "DELETE FROM games WHERE game_room=? AND creator=?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param('ss', $gameRoom, $this->creator);
        if ($stmt->execute()) {
            return "Game room deleted successfully!";
        } else {
            return "Error deleting game room: " . $this->db->getLastError();
        }
    }
}
?>
