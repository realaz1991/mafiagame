<?php
class User {
    private $username;

    public function __construct($username) {
        $this->username = $username;
    }

    public function getUsername() {
        return $this->username;
    }

    public static function isLoggedIn() {
        return isset($_SESSION['username']);
    }

    public static function redirectToLogin() {
        header("Location: login.php");
        exit();
    }

    public static function getCurrentUser() {
        if (self::isLoggedIn()) {
            return new User($_SESSION['username']);
        }
        return null;
    }
}
?>
