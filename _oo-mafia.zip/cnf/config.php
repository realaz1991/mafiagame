<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'u458362099_oomafia');
define('DB_PASS', 'Ruksare453');
define('DB_NAME', 'u458362099_oomafia');
?>

