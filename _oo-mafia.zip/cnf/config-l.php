<?php
$servername = "localhost";
$username = "u458362099_oomafia";
$password = "Ruksare453";
$dbname = "u458362099_oomafia";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
