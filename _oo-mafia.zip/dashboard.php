<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('cnf/config.php');
include('db/Database.php');
include('usr/User.php');
include('gm/GameRoom.php');
include('gm/Game.php');

session_start();

if (!User::isLoggedIn()) {
    User::redirectToLogin();
}

$username = $_SESSION['username'];
$user = new User($username);
$db = new Database(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$gameRoomManager = new GameRoom($db, $username);
$gameManager = new Game($db);

// Oda oluşturma işlemi
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_room'])) {
    $gameRoom = $_POST['game_room'];
    echo $gameRoomManager->createRoom($gameRoom);
}

// Var olan kullanıcının oluşturduğu odaları getirme
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10; // Her seferde yüklenecek oda sayısı
$userRooms = $gameRoomManager->getUserRooms($page, $limit);

// Kullanıcı ekleme işlemi
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_player'])) {
    $gameRoom = $_POST['game_room'];
    $playerUsername = $_POST['player_username'];
    echo $gameManager->addPlayer($gameRoom, $playerUsername);
}

// Oyunu başlatma
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['start_game'])) {
    $gameRoom = $_POST['game_room'];
    echo $gameManager->startGame($gameRoom);
}

// Kullanıcının en son oynadığı oyun sonucunu getirme
$lastGameResult = $gameManager->getLastGameResult($username);
$specialInfo = '';
if ($lastGameResult && ($lastGameResult['role'] == 'Mafia' || $lastGameResult['role'] == 'Don Mafia' || $lastGameResult['role'] == 'Consigliere')) {
    $specialInfo = $gameManager->getSpecialInfo($lastGameResult['game_room'], $lastGameResult['role']);
}

// Include special_info in the last game result array
if (isset($_GET['action']) && $_GET['action'] == 'load_last_game_result') {
    $lastGameResult = $gameManager->getLastGameResult($username);
    if ($lastGameResult) {
        $specialInfo = $gameManager->getSpecialInfo($lastGameResult['game_room'], $lastGameResult['role']);
        header('Content-Type: application/json');
        echo json_encode([
            'game_room' => $lastGameResult['game_room'],
            'role' => $lastGameResult['role'],
            'special_info' => $specialInfo
        ]);
        exit();
    } else {
        echo json_encode(['error' => 'No game results found.']);
        exit();
    }
}

// Oda silme işlemi
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_room'])) {
    $gameRoom = $_POST['game_room'];
    echo $gameRoomManager->deleteRoom($gameRoom);
}

$db->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" type="text/css" href="style1.css">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <script>
        function createCard(role, special_info) {
            const cardContainer = document.createElement('div');
            cardContainer.className = 'card1-container';

            const card = document.createElement('div');
            card.className = 'card1';

            const cardText = document.createElement('div');
            cardText.className = '';
            cardText.textContent = role;

            const cardInfo = document.createElement('div');
            cardInfo.className = '';
            if (role === 'Mafia' || role === 'Don Mafia') {
                cardInfo.textContent = special_info;
                cardInfo.style.display = 'block';
            }
        }

        function displayGameResults(gameRoom, role, specialInfo) {
            createCard(role, specialInfo);

            document.getElementById('last_game_room').textContent = gameRoom;
            document.getElementById('last_game_role').textContent = role;

            if (role === 'Mafia' || role === 'Don Mafia') {
                document.getElementById('special_info').textContent = specialInfo;
            } else {
                document.getElementById('special_info').textContent = '';
            }
        }

        function loadGameResults() {
            fetch('dashboard.php?action=load_last_game_result')
                .then(response => response.json())
                .then(result => {
                    if (result.game_room && result.role) {
                        displayGameResults(result.game_room, result.role, result.special_info || '');
                    } else {
                        displayGameResults('No game results found.', '', '');
                    }
                })
                .catch(error => console.error('Error polling game results:', error));
        }

        setInterval(loadGameResults, 5000); // Sonuçları her 5 saniyede bir kontrol et
        loadGameResults();
    </script>
</head>
<body>
    <h3>Welcome, <?php echo htmlspecialchars($user->getUsername()); ?></h3>

    <div id="game-results-section">
        <h2>Game Results</h2>
        <div id="game-results-container">
            <div class="card1">
                <div class="title">Last Game Room</div>
                <div class="content" id="last_game_room"><?php echo htmlspecialchars($lastGameResult['game_room'] ?? ''); ?></div>
            </div>
            </br>
            <div class="card1">
                <div class="title">Last Game Role</div>
                <div class="content" id="last_game_role"><?php echo htmlspecialchars($lastGameResult['role'] ?? ''); ?></div>
            </div>
            </br>
            <div class="card1">
                <div class="title">Special Info</div>
                <div class="content" id="special_info"><?php echo htmlspecialchars($specialInfo ?? ''); ?></div>
            </div>
            <br>
        </div>
    </div>

    <br>

    <h2>Your Game Rooms</h2>
    <ul id="game-rooms-container">
        <?php foreach ($userRooms as $room): ?>
            <li>
                <?php echo htmlspecialchars($room['game_room']); ?>
                <form method="POST" action="dashboard.php" class="inline">
                    <input type="hidden" name="game_room" value="<?php echo htmlspecialchars($room['game_room']); ?>">
                    <label for="player_username">Add Player:</label>
                    <input type="text" id="player_username" name="player_username" required>
                    <input type="submit" name="add_player" value="Add">
                </form>
                <form method="POST" action="dashboard.php" class="inline">
                    <input type="hidden" name="game_room" value="<?php echo htmlspecialchars($room['game_room']); ?>">
                    <input type="submit" name="start_game" value="Start Game">
                </form>
                <form method="POST" action="dashboard.php" class="inline">
                    <input type="hidden" name="game_room" value="<?php echo htmlspecialchars($room['game_room']); ?>">
                    <input type="submit" name="delete_room" value="Delete Game Room">
                </form>
            </li>
        <?php endforeach; ?>
    </ul>

    <div id="loader" style="display: none;">Loading more rooms...</div>

    <h4>Create Game Room</h4>
    <form method="POST" action="dashboard.php">
        <label for="game_room">Game Room Name:</label>
        <input type="text" id="game_room" name="game_room" required>
        <input type="submit" name="create_room" value="Create">
    </form>

    <a href="logout.php">Logout</a>
</body>
</html>
