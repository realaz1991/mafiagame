<?php
include('config.php');
session_start();

if (!isset($_SESSION['admin_username'])) {
    header("Location: admin_login.php");
    exit();
}

$admin_username = $_SESSION['admin_username'];

// Oda oluşturma işlemi
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_room'])) {
    $game_room = $_POST['game_room'];

    $sql = "SELECT * FROM games WHERE game_room='$game_room'";
    $result = $conn->query($sql);

    if ($result->num_rows == 0) {
        $sql = "INSERT INTO games (game_room, players) VALUES ('$game_room', '')";
        if ($conn->query($sql) === TRUE) {
            echo "New game room created successfully!";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Game room already exists. Please choose a different name.";
    }
}

// Var olan odalara oyuncu ekleme
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_player'])) {
    $game_room = $_POST['game_room'];
    $player_username = $_POST['player_username'];

    $sql = "SELECT * FROM users WHERE username='$player_username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $sql = "SELECT * FROM games WHERE game_room='$game_room'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $players = $row['players'];
            if (strpos($players, $player_username) === false) {
                $players .= $player_username . ",";
                $sql = "UPDATE games SET players='$players' WHERE game_room='$game_room'";
                if ($conn->query($sql) === TRUE) {
                    echo "Player added successfully!";
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            } else {
                echo "Player is already in the game room.";
            }
        } else {
            echo "Game room not found.";
        }
    } else {
        echo "Player not found.";
    }
}

// Oyunu başlatma
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['start_game'])) {
    $game_room = $_POST['game_room'];

    $sql = "SELECT * FROM games WHERE game_room='$game_room'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $players = rtrim($row['players'], ',');
        $players_array = explode(',', $players);

        if (count($players_array) >= 4) {
            shuffle($players_array);
            $roles = ['Şerif', 'Mafia', 'Mafia', 'Komikadze'];
            $remaining_roles = array_fill(0, count($players_array) - 4, 'Sakin');
            $roles = array_merge($roles, $remaining_roles);

            foreach ($players_array as $index => $player) {
                $role = $roles[$index];
                $sql = "INSERT INTO game_results (username, role, game_room) VALUES ('$player', '$role', '$game_room')";
                $conn->query($sql);
            }
            $sql = "UPDATE games SET status='started' WHERE game_room='$game_room'";
            $conn->query($sql);
            echo "Game started successfully!";
        } else {
            echo "Not enough players to start the game.";
        }
    } else {
        echo "Game room not found.";
    }
}

// Var olan odaları getirme
$sql = "SELECT * FROM games";
$result = $conn->query($sql);
$rooms = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $rooms[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h1>Admin Panel - Welcome, <?php echo $admin_username; ?></h1>
    <h2>Create Game Room</h2>
    <form method="POST" action="admin.php">
        <label for="game_room">Game Room Name:</label>
        <input type="text" id="game_room" name="game_room" required>
        <input type="submit" name="create_room" value="Create">
    </form>
    <h2>Existing Game Rooms</h2>
    <ul>
        <?php foreach ($rooms as $room): ?>
            <li>
                <?php echo htmlspecialchars($room['game_room']); ?>
                <form method="POST" action="admin.php" style="display:inline;">
                    <input type="hidden" name="game_room" value="<?php echo htmlspecialchars($room['game_room']); ?>">
                    <label for="player_username">Add Player:</label>
                    <input type="text" id="player_username" name="player_username" required>
                    <input type="submit" name="add_player" value="Add">
                </form>
                <form method="POST" action="admin.php" style="display:inline;">
                    <input type="hidden" name="game_room" value="<?php echo htmlspecialchars($room['game_room']); ?>">
                    <input type="submit" name="start_game" value="Start Game">
                </form>
            </li>
        <?php endforeach; ?>
    </ul>
</body>
</html>
