function toggleSidePanel() {
    var sidePanel = document.getElementById('sidePanel');
    if (sidePanel.classList.contains('open')) {
        sidePanel.classList.remove('open');
    } else {
        sidePanel.classList.add('open');
    }
}
